
public interface EventListener 
{
	void move(String colour, int from, int to);
	
	void cheat();
}
