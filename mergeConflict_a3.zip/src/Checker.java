import javax.swing.*;

public class Checker extends JComponent 
{

int colour;


}
