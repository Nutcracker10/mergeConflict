# mergeConflict : Backgammon

| Member | Student Number |
| :----: | :------------: |
| James Kirwan | 17402782 | 
| Caoimhe Tiernan | 17336331 | 
| Saoirse Houlihan | 17340803 |

# Controls
1. Type quit to exit the program.
2. Type wName and a string to enter a name for the white player.
3. Type bName and a string to enter a name for the black player.
4. Type move followed by a letter to make that move.
5. Type next to switch to the next player's turn.
6. Type cheat to jump to the end of the game.