public class NoCheckerException extends RuntimeException
{

}
