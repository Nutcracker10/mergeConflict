
public interface MoveListener 
{
	void move(String colour, int from, int to);
}
